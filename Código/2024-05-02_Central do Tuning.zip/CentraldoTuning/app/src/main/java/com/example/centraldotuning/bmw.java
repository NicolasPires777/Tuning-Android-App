package com.example.centraldotuning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class bmw extends AppCompatActivity {

    Button bmw320i,bmw125i,bmwm3,bmwm4,bmwm5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmw);

        bmw320i = findViewById(R.id.btn320i);
        bmw125i = findViewById(R.id.btn125i);
        bmwm5 = findViewById(R.id.btnm5);
        bmwm4 = findViewById(R.id.btnm4);
        bmwm3 = findViewById(R.id.btnm3);

        bmw320i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bmw320i=new Intent(getApplicationContext(),BMW320i.class);
                startActivity(bmw320i);
            }
        });

        bmw125i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bmw125i=new Intent(getApplicationContext(),BMW125i.class);
                startActivity(bmw125i);
            }
        });

        bmwm5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bmwm5=new Intent(getApplicationContext(),BMWm5.class);
                startActivity(bmwm5);
            }
        });

        bmwm4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bmwm4=new Intent(getApplicationContext(),BMWm4.class);
                startActivity(bmwm4);
            }
        });

        bmwm3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bmwm3=new Intent(getApplicationContext(),BMWm3.class);
                startActivity(bmwm3);
            }
        });
    }


}