package com.example.centraldotuning;

import static com.example.centraldotuning.R.id.btnlancerbodykit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class lancer extends AppCompatActivity {

    Button ponteira, aerofolio, farois, suspensao, remap, pneus, bodykit, filtroar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lancer);

        ponteira=findViewById(R.id.btnlancerponteira);
        aerofolio=findViewById(R.id.btnlanceraerofolio);
        farois=findViewById(R.id.btnlancerlanterna);
        suspensao=findViewById(R.id.btnlancersusp);
        remap=findViewById(R.id.btnlanceremap);
        pneus=findViewById(R.id.btnlancerpneus);
        filtroar=findViewById(R.id.btnlancerar);
        bodykit=findViewById(btnlancerbodykit);

        ponteira.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        aerofolio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://lista.mercadolivre.com.br/aerofolio-lancer?matt_tool=26344982&matt_word=Default_URL_MLB&matt_source=google&matt_campaign_id=11297243419&matt_ad_group_id=111150047976&matt_match_type=&matt_network=g&matt_device=c&matt_creative=528938304675&matt_keyword=&matt_ad_position=&matt_ad_type=&matt_merchant_id=&matt_product_id=&matt_product_partition_id=&matt_target_id=dsa-19959388920&cq_src=google_ads&cq_cmp=11297243419&cq_net=g&cq_plt=gp&cq_med=&gad_source=1&gclid=CjwKCAjw88yxBhBWEiwA7cm6pZM599BGZkn08zdhA9qpF4qGcgeGFd6cuDwRweWrmwwKsfrTB4JL_hoCNWoQAvD_BwE";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        farois.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.lancershopbrasil.com.br/lista/acessorios-veiculos/pecas-carros-caminhonetes/iluminacao/lancer-farol#applied_filter_id%3Dcategory%26applied_filter_name%3DCategorias%26applied_filter_order%3D2%26applied_value_id%3DMLB2228%26applied_value_name%3DIlumina%C3%A7%C3%A3o%26applied_value_order%3D2%26applied_value_results%3D4%26is_custom%3Dfalse";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        suspensao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.eibachstore.com.br/pro-kit-mitsubishi-lancer-2011";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        remap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.perfortech.com.br/performance/370/mitsubishi/lancer/-2010/20-160cv";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        pneus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.michelin.com.br/auto/browse-tyres/by-vehicle/mitsubishi/lancer/2-dot-0-16v-hl-cvt";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        bodykit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.lancershopbrasil.com.br/lista/acessorios-veiculos/pecas-carros-caminhonetes/carroceria/_BRAND_1138#applied_filter_id%3Dcategory%26applied_filter_name%3DCategorias%26applied_filter_order%3D2%26applied_value_id%3DMLB191835%26applied_value_name%3DCarroceria%26applied_value_order%3D1%26applied_value_results%3D16%26is_custom%3Dfalse";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        filtroar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.tuningparts.com.br/busca/filtro%20de%20ar%20lancer/";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });
    }
}