package com.example.centraldotuning;

import static com.example.centraldotuning.R.id.btnlancerbodykit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class lancer extends AppCompatActivity {

    Button ponteira, aerofolio, farois, suspensao, remap, pneus, bodykit, filtroar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lancer);

        ponteira=findViewById(R.id.btnlancerponteira);
        aerofolio=findViewById(R.id.btnlanceraerofolio);
        farois=findViewById(R.id.btnlancerlanterna);
        suspensao=findViewById(R.id.btnlancersusp);
        remap=findViewById(R.id.btnlanceremap);
        pneus=findViewById(R.id.btnlancerpneus);
        filtroar=findViewById(R.id.btnlancerar);
        bodykit=findViewById(btnlancerbodykit);

        ponteira.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        aerofolio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        farois.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        suspensao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        remap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        pneus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        bodykit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.lancershopbrasil.com.br/lista/acessorios-veiculos/pecas-carros-caminhonetes/carroceria/_BRAND_1138#applied_filter_id%3Dcategory%26applied_filter_name%3DCategorias%26applied_filter_order%3D2%26applied_value_id%3DMLB191835%26applied_value_name%3DCarroceria%26applied_value_order%3D1%26applied_value_results%3D16%26is_custom%3Dfalse";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        filtroar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.tuningparts.com.br/busca/filtro%20de%20ar%20lancer/";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });
    }
}