package com.example.centraldotuning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button volksbtn,bmwbtn,jdmbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bmwbtn=findViewById(R.id.bmwbtn);
        jdmbtn=findViewById(R.id.jdmbtn);
        volksbtn=findViewById(R.id.volksbtn);

        volksbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volks=new Intent(getApplicationContext(),volks.class);
                startActivity(volks);
            }
        });

        bmwbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bmw=new Intent(getApplicationContext(),bmw.class);
                startActivity(bmw);
            }
        });

        jdmbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent jdm=new Intent(getApplicationContext(),jdm.class);
                startActivity(jdm);
            }
        });
    }
}