package com.example.centraldotuning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class jdm extends AppCompatActivity {

    Button lancer,nissan350z,nissan370z,gtr,eclipse,civic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jdm);

        lancer=findViewById(R.id.btnlancer);
        nissan350z=findViewById(R.id.btn350z);
        nissan370z=findViewById(R.id.btn370z);
        gtr=findViewById(R.id.btngtr);
        eclipse=findViewById(R.id.btneclipse);
        civic=findViewById(R.id.btncivic);

        lancer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent lancer=new Intent(getApplicationContext(),lancer.class);
                startActivity(lancer);
            }
        });

        nissan350z.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nissan370z=new Intent(getApplicationContext(),nissan350z.class);
                startActivity(nissan370z);
            }
        });

        nissan370z.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nissan350z=new Intent(getApplicationContext(),nissan370z.class);
                startActivity(nissan350z);
            }
        });

        gtr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gtr=new Intent(getApplicationContext(),gtr.class);
                startActivity(gtr);
            }
        });

        eclipse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent eclipse=new Intent(getApplicationContext(),eclipse.class);
                startActivity(eclipse);
            }
        });

        civic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent civic=new Intent(getApplicationContext(),civic.class);
                startActivity(civic);
            }
        });
    }
}