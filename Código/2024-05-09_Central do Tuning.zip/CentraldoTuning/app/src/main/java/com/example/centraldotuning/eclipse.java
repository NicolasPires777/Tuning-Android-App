package com.example.centraldotuning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class eclipse extends AppCompatActivity {

    Button ponteira,turbina,susp,bancos,remap,pneus,bodykit,ar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eclipse);

        ponteira=findViewById(R.id.btnponteira);
        turbina=findViewById(R.id.btnaerofolio);
        susp=findViewById(R.id.btnlanterna);
        bancos=findViewById(R.id.btnsusp);
        remap=findViewById(R.id.btnremap);
        pneus=findViewById(R.id.btnpneus);
        bodykit=findViewById(R.id.btnbodykit);
        ar=findViewById(R.id.btnar);

        ponteira.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        turbina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://lista.mercadolivre.com.br/turbina-original-mitsubishi-eclipse-gst?matt_tool=26344982&matt_word=Default_URL_MLB&matt_source=google&matt_campaign_id=11297243419&matt_ad_group_id=111150047976&matt_match_type=&matt_network=g&matt_device=c&matt_creative=471253612030&matt_keyword=&matt_ad_position=&matt_ad_type=&matt_merchant_id=&matt_product_id=&matt_product_partition_id=&matt_target_id=dsa-19959388920&cq_src=google_ads&cq_cmp=11297243419&cq_net=g&cq_plt=gp&cq_med=&gad_source=1&gclid=Cj0KCQjw6PGxBhCVARIsAIumnWaqk4hTURHjtkgEEaasuR769VXFExZ8pXc2sRaB_y-JrUnDRUYQpDMaAt73EALw_wcB";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        susp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.dudaparts.com.br/MLB-3118854406-par-amortecedor-dianteiro-mitsubishi-eclipse-gst-95-a-99-kyb-_JM";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        bancos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.courotecabc.com.br/mitsubishi-eclipse-gst-1995.php";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        remap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.perfortech.com.br/performance/744/mitsubishi/eclipse-cross/2020/15-turbo";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        pneus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.dpaschoal.com.br/pneus-e-camaras/Carro/ECLIPSE%20GST%202@dot@0%2016V%20COUPE?PS=12&map=c,specificationFilter_18,specificationFilter_19";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        bodykit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.dredworks.com/pagina-de-produto/body-kit-splitters-eclipse-gst";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        ar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.kaledautoparts.com.br/Mitsubishi/Eclipse-GST/filtro-de-ar-kn-conico-universal-mitsubishi-eclipse-gst-95___1193806-SIT.html";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

    }
}