package com.example.centraldotuning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class volks extends AppCompatActivity {

    Button btngolf, btnjetta, btnfusca, btnpolo, btnup, btngol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volks);

        btngolf = findViewById(R.id.btngolf);
        btnjetta = findViewById(R.id.btnjetta);
        btnfusca = findViewById(R.id.btnfusca);
        btngol = findViewById(R.id.btngol);
        btnpolo = findViewById(R.id.btnpolo);
        btnup = findViewById(R.id.btnup);

        btngolf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent golf=new Intent(getApplicationContext(),VWgolf.class);
                startActivity(golf);
            }
        });

        btnjetta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent jetta=new Intent(getApplicationContext(),VWjetta.class);
                startActivity(jetta);
            }
        });

        btnfusca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fusca=new Intent(getApplicationContext(),VWfusca.class);
                startActivity(fusca);
            }
        });

        btngol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gol=new Intent(getApplicationContext(),VWgol.class);
                startActivity(gol);
            }
        });

        btnpolo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent polo=new Intent(getApplicationContext(),VWpolo.class);
                startActivity(polo);
            }
        });

        btnup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent up=new Intent(getApplicationContext(),VWup.class);
                startActivity(up);
            }
        });
    }
}