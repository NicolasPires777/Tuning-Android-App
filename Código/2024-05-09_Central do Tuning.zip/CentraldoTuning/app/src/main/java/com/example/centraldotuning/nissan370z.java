package com.example.centraldotuning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class nissan370z extends AppCompatActivity {

    Button ponteira, susp, turbina, hb, remap, pneus, bodykit, ar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nissan370z);

        ponteira = findViewById(R.id.btnponteira);
        susp = findViewById(R.id.btnaerofolio);
        turbina = findViewById(R.id.btnlanterna);
        hb = findViewById(R.id.btnsusp);
        remap = findViewById(R.id.btnremap);
        pneus = findViewById(R.id.btnpneus);
        bodykit = findViewById(R.id.btnbodykit);
        ar = findViewById(R.id.btnar);

        ponteira.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        susp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.eibachstore.com.br/pro-kit-nissan-370z-2009";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        turbina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.ebay.com/itm/224092546109?fits=Model%3A370Z%7CMake%3ANissan&itmmeta=01HXEPAHAYG1QZW5KTEARJVXN5&hash=item342cf4e43d:g:oJ8AAOSwBWdfBcyW&amdata=enc%3AAQAJAAAA4OPrYbdcQQOpK4A3h1E%2B35VT1vRb1ME2MO9DXasZYRawBqBNt1fNk%2F8gfBVhggmXx0Ws6UkPBgX46oFJ5uee%2BL6BKb90sRw8QNViWvqQ9N0h1OQOvlb6jirxlh%2FoGJZ2sMjrYjL3khVEL1Of7P7EvnnUHd7ESMmhFrKIaVzmSYDjKmHaYaDPEsDPEVEMqnIBGcITn61seNEa%2B2NPmPzFuei2AWwvnB5ycZp%2FjbKLnpyfRO%2FCmRwCcCW%2F6oM3fC7L7TXz2VXU8QBT7eBLgCjhNNEmDElD0%2FpIFGmpEf7G8Qle%7Ctkp%3ABFBMypWq1utj";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        hb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.topjdmstore.com/collections/drift-handbrakes";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        remap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.perfortech.com.br/performance/379/nissan/370z/-2008/37-328cv";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        pneus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.gama4x4.com.br/kit-4-pneus-aro-18-original-nissan-370z-245-45zr18-100y-yokohoma-br.html";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        bodykit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.fly1motorsports.com/nissan370z";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        ar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.tuningparts.com.br/intake-k-n-nissan-370z-09-16-c-filtro-ar-conico?_pid=ARpbc";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

    }
}