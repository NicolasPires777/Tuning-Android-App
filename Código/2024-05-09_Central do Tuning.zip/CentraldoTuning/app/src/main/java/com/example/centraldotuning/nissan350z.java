package com.example.centraldotuning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class nissan350z extends AppCompatActivity {

    Button ponteira, susp, turbina, hb, remap, pneus, bodykit, ar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nissan350z);

        ponteira=findViewById(R.id.btnponteira);
        susp=findViewById(R.id.btnaerofolio);
        turbina=findViewById(R.id.btnlanterna);
        hb=findViewById(R.id.btnsusp);
        pneus=findViewById(R.id.btnpneus);
        remap=findViewById(R.id.btnremap);
        bodykit=findViewById(R.id.btnbodykit);
        ar=findViewById(R.id.btnar);

        ponteira.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        susp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.lojaimpactoespeciais.com.br/busca?n=350z";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        turbina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://br.ebay.com/b/Turbo-Chargers-Parts-for-Nissan-350Z/33742/bn_1457658";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        hb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.topjdmstore.com/collections/drift-handbrakes";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        pneus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.ggracing.com.br/MLB-3733101396-par-de-pneus-25535r18-94y-delmax-drift-_JM";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        remap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.perfortech.com.br/performance/378/nissan/350z/2004-a-2009/35-313cv";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        bodykit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://nilsonayres.mercadoshops.com.br/MLB-1571051104-kit-aerodinmico-widebody-kit-cwd-para-nissan-350z-_JM";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        ar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.tuningparts.com.br/intake-k-n-nissan-350z-07-08-c-filtro-ar-conico?_pid=xmvbc";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

    }
}