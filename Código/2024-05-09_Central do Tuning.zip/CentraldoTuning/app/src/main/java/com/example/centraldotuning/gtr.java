package com.example.centraldotuning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class gtr extends AppCompatActivity {

    Button ponteira, down, turbina, susp, remap, pneus, lb, ar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gtr);

        ponteira=findViewById(R.id.btnponteira);
        down=findViewById(R.id.btnaerofolio);
        turbina=findViewById(R.id.btnlanterna);
        susp=findViewById(R.id.btnsusp);
        remap=findViewById(R.id.btnremap);
        pneus=findViewById(R.id.btnpneus);
        lb=findViewById(R.id.btnbodykit);
        ar=findViewById(R.id.btnar);

        ponteira.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.novaracing.com.br/produto/downpipe-nissan-gtr-inox-409-r35-skyline/5098255";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        turbina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.amsperformance.com/product/ams-performance-omega-11-r35-gtr-turbo-kit/";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        susp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://eibach.com/product/6389.880";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        remap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.rstuning.co.uk/product/nissan-r35-gt-r-custom-ecutek-remap/";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        pneus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.tireshop.com.br/3848/Pneu-Goodyear-Eagle-F1-SuperSport-255-40-ZR20-101Y-NF0-(Original-Porsche-Taycan)?gad_source=1&gclid=Cj0KCQjw6PGxBhCVARIsAIumnWY40iSn65KKAKoETG-r-8jxuis-DuANa-z9HkBrKphLr9ov_VUSivYaAvE8EALw_wcB";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        lb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://libertywalk.co.jp/bodykit/lb-works/nissan-r35-gtr/";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        ar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.gpparts.com.br/sprint-filter-p1052s-f1-85-nissan-gt-r-r35";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });
    }
}