package com.example.centraldotuning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class civic extends AppCompatActivity {

    Button ponteira, downpipe, turbina, suspensao, remap, pneus, bodykit, filtroar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_civic);

        ponteira=findViewById(R.id.btnponteira);
        downpipe=findViewById(R.id.btnaerofolio);
        turbina=findViewById(R.id.btnlanterna);
        suspensao=findViewById(R.id.btnsusp);
        remap=findViewById(R.id.btnremap);
        pneus=findViewById(R.id.btnpneus);
        bodykit=findViewById(R.id.btnbodykit);
        filtroar=findViewById(R.id.btnar);

        ponteira.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thsparts.com.br/ponteiras";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        downpipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://lista.mercadolivre.com.br/downpipe-civic#D[A:downpipe%20civic%20]";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        turbina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://stockes.com.br/produtos/kit-turbo-transformacao-350hp-para-honda-civic/";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        suspensao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.eibachstore.com.br/pro-kit-honda-civic-18mt-06a16";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        remap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.perfortech.com.br/performance/775/honda/civic/2017/15-turbo";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        pneus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.michelin.com.br/auto/browse-tyres/by-vehicle/honda/civic-sedan/1-dot-5-turbo-touring-cvt/2020/215---50R17-91V";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        bodykit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://lista.mercadolivre.com.br/body-kit-honda-civic";
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

        filtroar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.carperformance.com.br/produtos/filtro-de-ar-kit-intake-kn-63-3516-civic-touring-1-5-turbo-g10/";
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                startActivity(intent);
            }
        });

    }
}